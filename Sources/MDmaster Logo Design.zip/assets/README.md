# MDmaster app icon — handoff

Direction **1d ("Caret")**: downward caret over an accent baseline rule, on a violet gradient tile.

## Files

- `mdmaster-icon.svg` — vector source, 1024×1024 artboard. Single source of truth.
- `png/icon-{1024,512,256,128,64,32,16}.png` — flat rasters, transparent outside the tile.

## Specs (1024 artboard)

| Element | Value |
| --- | --- |
| Tile | 1024×1024, corner radius 229 |
| Gradient | `#6D5CE7` → `#2E2270`, top-left to bottom (x2=0.42, y2=1) |
| Caret | polyline 307,430 → 512,635 → 717,430; stroke `#FFFFFF` 77px, round cap/join |
| Rule | x 307, y 717, 410×51, radius 26, fill `#EFC98C` |
| Wordmark font | Space Grotesk 700 (UI only, not in the icon) |

## macOS packaging

The corner radius here is a plain rounded rect. For shipping, mask the artwork with Apple's
official squircle template from the macOS App Icon design resources rather than this radius —
it's the one visible difference from a native-looking dock icon.

Apple's macOS icon grid also insets the artwork inside the canvas (824×824 tile inside a
1024×1024 transparent canvas for `.icns`). Regenerate at that inset before building the iconset.

```sh
mkdir MDmaster.iconset
cp png/icon-16.png    MDmaster.iconset/icon_16x16.png
cp png/icon-32.png    MDmaster.iconset/icon_16x16@2x.png
cp png/icon-32.png    MDmaster.iconset/icon_32x32.png
cp png/icon-64.png    MDmaster.iconset/icon_32x32@2x.png
cp png/icon-128.png   MDmaster.iconset/icon_128x128.png
cp png/icon-256.png   MDmaster.iconset/icon_128x128@2x.png
cp png/icon-256.png   MDmaster.iconset/icon_256x256.png
cp png/icon-512.png   MDmaster.iconset/icon_256x256@2x.png
cp png/icon-512.png   MDmaster.iconset/icon_512x512.png
cp png/icon-1024.png  MDmaster.iconset/icon_512x512@2x.png
iconutil -c icns MDmaster.iconset
```

## Small sizes

At 16 and 32px the caret stroke lands near 1–2px. If it reads soft, thicken the stroke to
84–90 (on the 1024 grid) for those two sizes only and drop the accent rule at 16px.
